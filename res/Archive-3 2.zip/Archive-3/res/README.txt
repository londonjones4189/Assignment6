﻿Program Features README
Program allows users to:
Features of the design that work competely
1.) Rebalancing works in both modelMax and portfolioDate but does not correctly for loop in the
the controler
2.)Composition works in both modelMax and portfoliodate and works in the controller
3.)Decompostion works in both modelMax and portfolioDate and works in the controller
4.) The bar chart works compeletly
6.) buy and sell work comepeletly
7.) The feature of disallowing fractional shares does not work and if you enter a wrong portfoli
name at some point in the program it does not work
8.) retriving files work
9.) presiting the files work
