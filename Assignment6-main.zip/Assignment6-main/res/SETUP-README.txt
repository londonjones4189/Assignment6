List of stocks program supports (Start day ~ End day)


//Jar file needs to be in a folder with the res folder to run

How to create portfolios (1 with 3 different stocks, a second portfolio with 2 different stocks
 and two to query their value on a specific date)

1st: Open up jar file 

2nd : Enter 2 (no spaces required), this option will take you to the create/edit portfolio menu 

3rd: Once you get to the create/edit portfolio menu, enter 1. Once you hit enter you will have the
option to type in the name for the portfolio, enter the name you choose for the portfolio.

4th: Once you create that portfolio it will take you to the main menu, repeat steps 2 and 3.
However, You can not name this portfolio the same name as the last, if you do the program will
throw and error and take you back to main menu

5th: After the last step, you will be taken back to create/edit menu. Select option 2 again to be
taken
back to create/edit portfolio method. Once at the new menu, enter 2 to edit previous portfolio.

6th: The program will ask which portfolio you will like to edit, enter the portfolio's name. After
doing that the program will ask you whether you will like to add or remove stocks
from your portfolio. Enter 1, this is the option to adding stocks to a specific portfolio.

7th: Now enter the ticker of the stock which you would like the enter, then enter the number of
stock shares  you would like to add to selected portfolio.

8th: You wil also be asked to enter a date which you will enter by da, month, year
9th: Once you finsih the portfolio you can go back to main meny then slect 2
you will be brpught back to create/edit portfolo menu where you can select the get value option

10th: now enter the name of the portfilo you want to retrive and it get the value of the portfolio

There are some bugs in the program that cause the program to stop such as enntering the
wrong portfolio name, these methods work in the interface but there are some parts
of the controller that won't allow you to go forward if a mistake is made



8th: Repeat steps on portfolios until you have desired amount of stocks in each

9th: After that you will be taken back to the main menu,
to query about a portfolio's on a specific date enter 2.
Now that you're back at the create/edit portfolio menu enter 3.
Now enter the name of the portfolio you will like to query.
Then enter the date you will like to query about in the given format.
Upon entry it will give you the value of the portfolio on the given date.
